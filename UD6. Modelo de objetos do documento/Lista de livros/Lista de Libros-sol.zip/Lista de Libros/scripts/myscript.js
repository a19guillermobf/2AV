
let libros=[]

const formulario=document.querySelector("#libro-form")

const titulo=document.querySelector("#titulo")
const autor=document.querySelector("#autor")
const isbn=document.querySelector("#isbn")

const tbody=document.querySelector("#lista-libros")

const templateLibro=document.querySelector("#template-libro").content

function addLibro(){
    const libro={
        titulo:titulo.value,
        autor:autor.value,
        isbn:isbn.value,
        id:new Date().getTime()
    }
    libros.push(libro)
    sessionStorage.setItem("libros",JSON.stringify(libros))
    renderLibros()
}

function renderLibros(){
    tbody.innerHTML=""
    const fragmento=document.createDocumentFragment()
    libros.forEach(libro=>{
        const book=templateLibro.cloneNode(true)
        const tds=book.querySelectorAll("td")
        tds[0].textContent=libro.titulo
        tds[1].textContent=libro.autor
        tds[2].textContent=libro.isbn
        const a=tds[3].querySelector("a")
        a.dataset.id=libro.id
   /*       a.addEventListener("click",evento=>{
            let n=libros.findIndex(el=>el.id==evento.target.dataset.id)
            libros.splice(n,1)
            renderLibros()
        })*/        
        fragmento.appendChild(book)
    })
    tbody.appendChild(fragmento)
}

tbody.addEventListener("click",evento=>{
    evento.preventDefault()
    if (evento.target.dataset.id) {
        let n=libros.findIndex(el=>el.id==evento.target.dataset.id)
        libros.splice(n,1)
        sessionStorage.setItem("libros",JSON.stringify(libros))
    }
    renderLibros()
})

formulario.addEventListener("submit",eSubmit=>{
    eSubmit.preventDefault()
    if (libros.length) {
        if (libros.find(libro=>libro.isbn==isbn.value))
            alert("El libro ya esta registrado")
        else
            addLibro()
    } else 
        addLibro()
})

document.addEventListener("DOMContentLoaded",e=>{
    if (sessionStorage.getItem("libros")) {
        libros=JSON.parse(sessionStorage.getItem("libros"))
        renderLibros()
    }
})